MERGE INTO DM_CodeChallenge.dbo.DIM_Produto_Plano AS TARGET
USING
(
	SELECT DISTINCT
	ID_Produto,
	Step_Tarifacao,
	Valor_Step,
	GETDATE() AS Data_Carga
	FROM ST_CodeChallenge.dbo.tblProdutoPlanoStep
) AS SOURCE
(
	ID_Produto,
	Step_Tarifacao,
	Valor_Step,
	Data_Carga
)
ON (TARGET.ID_Produto = SOURCE.ID_Produto and TARGET.ID_Plano = SOURCE.Step_Tarifacao)

WHEN NOT MATCHED THEN	
INSERT
(
	ID_Produto_Plano,
	ID_Produto,
	ID_Plano,
	Valor,
	Data_Carga
)
VALUES
(

	SOURCE.ID_Produto,
	SOURCE.Step_Tarifacao,
	SOURCE.Valor_Step,
	SOURCE.Data_Carga
)

WHEN MATCHED THEN 		
UPDATE SET	
	ID_Produto = SOURCE.ID_Produto,
	ID_Plano = SOURCE.Step_Tarifacao,
	Valor = SOURCE.Valor_Step,
	Data_Carga = SOURCE.Data_Carga

;