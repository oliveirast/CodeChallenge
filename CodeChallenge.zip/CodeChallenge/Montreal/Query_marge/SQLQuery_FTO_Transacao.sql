MERGE INTO DM_CodeChallenge.dbo.FTO_Transacao AS TARGET
USING
( 
	SELECT DISTINCT
	t.ID_Transacao,
	t.ID_Assinatura,
	p.ID_Produto_Plano,
	t.Dt_Transacao,
	t.Status_Transacao,
	t.Valor,
	GETDATE() AS Data_Carga
	FROM ST_CodeChallenge.dbo.tblTransacao t 
	inner join DM_CodeChallenge.dbo.DIM_Produto_Plano p
	ON p.ID_Produto = t.ID_Produto and p.ID_Plano =  t.Step_Tarifacao
) AS SOURCE
(
	ID_Transacao,
	ID_Assinatura,
	ID_Produto_Plano,
	Dt_Transacao,
	Status_Transacao,
	Valor,
	Data_Carga
)
ON (TARGET.ID_Transacao = SOURCE.ID_Transacao)
WHEN NOT MATCHED THEN	
INSERT
(
	ID_Transacao,
	ID_Assinatura,
	ID_Produto_Plano,
	Data_Transacao,
	Status_Transacao,
	Valor_Transacao,
	Data_Carga
	
)
VALUES
(
	SOURCE.ID_Transacao,
	SOURCE.ID_Assinatura,
	SOURCE.ID_Produto_Plano,
	SOURCE.Dt_Transacao,
	SOURCE.Status_Transacao,
	SOURCE.Valor,	
	SOURCE.Data_Carga
)

WHEN MATCHED THEN 		
UPDATE SET	

	ID_Assinatura = SOURCE.ID_Assinatura,
	ID_Produto_Plano = SOURCE.ID_Produto_Plano,
	Data_Transacao = SOURCE.Dt_Transacao,
	Status_Transacao = SOURCE.Status_Transacao,
	Valor_Transacao = SOURCE.Valor,
	Data_Carga = SOURCE.Data_Carga

;
