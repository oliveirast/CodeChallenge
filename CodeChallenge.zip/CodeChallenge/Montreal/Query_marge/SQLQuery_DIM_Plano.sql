MERGE INTO DM_CodeChallenge.dbo.DIM_Plano AS TARGET
USING
(
	SELECT DISTINCT
	Step_Tarifacao,
	Plano,
	GETDATE() AS Data_Carga
	FROM ST_CodeChallenge.dbo.tblProdutoPlanoStep t
) AS SOURCE
(
	Step_Tarifacao,
	Plano,
	Data_Carga
)
ON (TARGET.ID_Plano = SOURCE.Step_Tarifacao)

WHEN NOT MATCHED THEN	
INSERT
(
	ID_Plano,
	Descricao_Plano,
	Data_Carga
)
VALUES
(
	SOURCE.Step_Tarifacao,
	SOURCE.Plano,
	SOURCE.Data_Carga
)

WHEN MATCHED THEN 		
UPDATE SET	
	Descricao_Plano = SOURCE.Plano,
	Data_Carga = SOURCE.Data_Carga

;