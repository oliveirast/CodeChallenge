MERGE INTO DM_CodeChallenge.dbo.DIM_Assinatura AS TARGET
USING
(
	SELECT DISTINCT
	ID_Assinatura,
	DDD,
	Numero_Tel,
	ID_Produto,
	Dt_Assinatura,
	Pendente,
	Status_Assinatura,
	Dt_Cancelamento,
	MotivoCancelamento,
	GETDATE() AS Data_Carga
	FROM ST_CodeChallenge.dbo.tblAssinatura
) AS SOURCE
(
	ID_Assinatura,
	DDD,
	Numero_Tel,
	ID_Produto,
	Dt_Assinatura,
	Pendente,
	Status_Assinatura,
	Dt_Cancelamento,
	MotivoCancelamento,
	Data_Carga
)
ON (TARGET.ID_Assinatura = SOURCE.ID_Assinatura)

WHEN NOT MATCHED THEN	
INSERT
(
	ID_Assinatura,
	DDD,
	Numero_Telefone,
	ID_Produto,
	Data_Assinatura,
	Status_Pendente,
	Status_Assinatura,
	Data_Cancelamento,
	Motivo_Cancelamento,
	Data_Carga
)
VALUES
(
	SOURCE.ID_Assinatura,
	SOURCE.DDD,
	SOURCE.Numero_Tel,
	SOURCE.ID_Produto,
	SOURCE.Dt_Assinatura,
	SOURCE.Pendente,
	SOURCE.Status_Assinatura,
	SOURCE.Dt_Cancelamento,
	SOURCE.MotivoCancelamento,
	SOURCE.Data_Carga
)

WHEN MATCHED THEN 		
UPDATE SET	
	ID_Assinatura = SOURCE.ID_Assinatura,
	DDD = SOURCE.DDD,
	Numero_Telefone = SOURCE.Numero_Tel,
	ID_Produto = SOURCE.ID_Produto,
	Data_Assinatura = SOURCE.Dt_Assinatura,
	Status_Pendente = SOURCE.Pendente,
	Status_Assinatura = SOURCE.Status_Assinatura,
	Data_Cancelamento = SOURCE.Dt_Cancelamento,
	Motivo_Cancelamento = SOURCE.MotivoCancelamento,
	Data_Carga = SOURCE.Data_Carga

;