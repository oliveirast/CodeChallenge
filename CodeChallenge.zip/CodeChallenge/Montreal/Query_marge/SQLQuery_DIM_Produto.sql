MERGE INTO DM_CodeChallenge.dbo.DIM_Produto AS TARGET
USING
(
	SELECT DISTINCT
	ID_Produto,
	Nome_Produto,
	Descricao_Produto,
	Dt_Ativacao,
	Status_Produto,
	GETDATE() AS Data_Carga
	FROM ST_CodeChallenge.dbo.tblProduto
) AS SOURCE
(
	ID_Produto,
	Nome_Produto,
	Descricao_Produto,
	Dt_Ativacao,
	Status_Produto,
	Data_Carga
)
ON (TARGET.ID_Produto = SOURCE.ID_Produto)

WHEN NOT MATCHED THEN	
INSERT
(
	ID_Produto,
	Nome_Produto,
	Descricao_Produto,
	Data_Ativacao,
	Status_Produto,
	Data_Carga
)
VALUES
(
	SOURCE.ID_Produto,
	SOURCE.Nome_Produto,
	SOURCE.Descricao_Produto,
	SOURCE.Dt_Ativacao,
	SOURCE.Status_Produto,
	SOURCE.Data_Carga
)

WHEN MATCHED THEN 		
UPDATE SET	
	Nome_Produto = SOURCE.Nome_Produto,
	Descricao_Produto = SOURCE.Descricao_Produto,
	Data_Ativacao = SOURCE.Dt_Ativacao,
	Status_Produto = SOURCE.Status_Produto,
	Data_Carga = SOURCE.Data_Carga

;